#!/usr/bin/env python
import sys

nextToken = None
prevToken = None
fileCounts = dict() # Assumes number of fileNames reasonably bounded as we need to print on one line

# This method formats the output for printing
def formatOutput():

    output = prevToken + " : " + str(len(fileCounts)) + " : {"
    pairs = []
    for key in sorted(fileCounts.iterkeys()):
        pairs.append("({}, {})".format(key, fileCounts[key]))
    output += (", ".join(pairs) + "}")
    return output

for line in sys.stdin:
    nextToken, fileEntries = line.strip().split("\t")

    # Same token as previous
    if nextToken == prevToken:

        # fileEntries may contain multiple entries if combiner ran
        for fileEntry in fileEntries.split(","):
            name, count = fileEntry.split(":")
            name = name[1:-1] # trim fileName
            # Add/Increment the count for this filename
            if name in fileCounts:
                fileCounts[name] += int(count)
            else:
                fileCounts[name] = int(count)

    else:
        if prevToken: # i.e. not the first line
            print(formatOutput()) # i.e. new token and prev exists, print counts for prev token
            fileCounts = dict() # Reset the dict for next token

        prevToken = nextToken # Set prev token for next iteration
        # Add the filename and counts for the first filename
        for fileEntry in fileEntries.split(","):
            name, count = fileEntry.split(":")
            fileCounts[name[1:-1]] = int(count)

# Don't forget the last line
if prevToken:
    print(formatOutput())
