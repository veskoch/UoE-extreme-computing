#!/usr/bin/env python
import sys

nextToken = None
prevToken = None
 # Not using a defaultdict as we need to reinstantiate this frequently
# Assuming number of possible filenames is reasonably bounded because reducer
# will have to output a superset of these fileNames in one line
fileCounts = dict()

for line in sys.stdin:
    nextToken, fileEntry = line.strip().split() # mapper input is (token   fileEntry)

    # next token is same as previous
    if nextToken == prevToken:

        name, count = fileEntry.split(":") # Don't need to use count here as it will always be 1 from mapper
        name = name[1:-1]
        # Add/update the count for the fileEntry
        if name in fileCounts:
            fileCounts[name] += 1
        else:
            fileCounts[name] = 1

    else: # i.e. next token is different
        if prevToken: # i.e. not the first line
            print(prevToken + "\t" + str(fileCounts)[1:-1].replace(" ", "")) # Print token and filenames
            fileCounts = dict() # Reset the fileCounts dict

        prevToken = nextToken # Set prev token for next iteration
        name, count = fileEntry.split(":") # Don't need to use count here as it will always be 1 from mapper
        fileCounts[name[1:-1]] = 1 # Add this token to the fileCounts

# Don't forget to print last token and filenames
if prevToken:
    print(prevToken + "\t" + str(fileCounts)[1:-1].replace(" ", ""))
