time hadoop jar /opt/hadoop/hadoop-2.7.3/share/hadoop/tools/lib/hadoop-streaming-2.7.3.jar \
-D mapred.reduce.tasks=1 \
-input /data/assignments/ex2/part1/large/ \
-output /user/s1774383/assignment2/task1/ \
-mapper mapper-t1.py \
-file /afs/inf.ed.ac.uk/user/s17/s1774383/EC/A2/submissionFolder/task1/mapper-t1.py \
-reducer reducer-t1.py \
-file /afs/inf.ed.ac.uk/user/s17/s1774383/EC/A2/submissionFolder/task1/reducer-t1.py \
-combiner combiner-t1.py \
-file /afs/inf.ed.ac.uk/user/s17/s1774383/EC/A2/submissionFolder/task1/combiner-t1.py
