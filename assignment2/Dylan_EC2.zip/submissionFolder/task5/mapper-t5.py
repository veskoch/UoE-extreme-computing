#!/usr/bin/env python
import sys
import random

samples = [] # Stores the sampled lines, assumes K is reasonably bounded
line_number = 0 # How many lines we've seen
k = 100 # The number of lines we wish to sample

for line in sys.stdin:

    # Fill the samples list intially with the first k lines
    if line_number < k:
        samples.append(line.strip())
    else:
        r = random.randint(0, line_number) # Generate a random number between 0 and number of lines seen
        if r < k: # if r < k we update we add this line to the samples at position r
            samples[r] = line.strip()

    line_number += 1 # Increment the number of lines seen

# Check for empty input
if samples:
    print("\n".join(samples))
else:
    print("Empty Input File")
