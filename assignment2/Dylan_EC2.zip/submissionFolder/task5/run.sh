cat /afs/inf.ed.ac.uk/group/teaching/exc/ex2/part3/webLarge.txt | ./mapper-t5.py  > result.txt
