#!/usr/bin/env python
import sys
from collections import defaultdict

s = 0.01 # Support threshold
e = s/10 # Error threshold is 10% of the support threshold
# Window size = 1/error threshold
# Rounding because no guarantee 1/e will be a whole number
w = int(round(1./e))

N = 0 # Size of the stream so far
cache = defaultdict(int)

for line in sys.stdin:

    N +=1 # Increment the number of lines seen so far
    cache[line.strip()] += 1 # Add/Update the count of this line in the cache

    if N % w == 0: # We are at a window boundary, decrement each counter by 1
        for key in cache.keys():
            if cache[key] == 1:
                del cache[key] # Delete this key it's count is 1
            else:
                cache[key] -= 1 # Decrement this key by 1

if N % w != 0: # If we have a smaller final window remember to decrement the values
    for key in cache.keys():
        if cache[key] == 1:
            del cache[key]
        else:
            cache[key] -= 1

# Print the queries greather than the threshold
for key in cache.iterkeys():
    value = cache[key]
    if value > ((s - e) * N):
        print(key)
