cat /afs/inf.ed.ac.uk/group/teaching/exc/ex2/part4/queriesLarge.txt | ./lossy-count.py > result.txt 
