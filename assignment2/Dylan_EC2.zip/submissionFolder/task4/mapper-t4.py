#!/usr/bin/env python
import sys
import random

line_number = 0 # Number of lines seen so far
sample = None # Holds the value of the line we sample

for line in sys.stdin:

    # Each line has P=(1/num_lines) of being the value stored in 'sample' 
    if random.randint(0, line_number) == 0:
        sample = line.strip() # Update sample
    line_number += 1 # Incremement the number of lines seen

# Print the line which has been sampled
if sample:
    print(sample)
