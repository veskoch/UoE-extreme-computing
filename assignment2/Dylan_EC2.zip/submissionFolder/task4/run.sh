time hadoop jar /opt/hadoop/hadoop-2.7.3/share/hadoop/tools/lib/hadoop-streaming-2.7.3.jar \
-D mapred.reduce.tasks=1 \
-input /data/assignments/ex2/part3/webLarge.txt \
-output /user/s1774383/assignment2/task4/ \
-mapper mapper-t4.py \
-file /afs/inf.ed.ac.uk/user/s17/s1774383/EC/A2/submissionFolder/task4/mapper-t4.py \
-reducer mapper-t4.py
