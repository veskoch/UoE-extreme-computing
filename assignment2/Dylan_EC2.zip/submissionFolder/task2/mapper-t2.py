#!/usr/bin/python
import sys

for line in sys.stdin:

    # Split on the 7th space, drop first and last tokens
    tokens = line.strip().split(" ", 7)[1:-1]

    # We only want questions
    if tokens[1][-3:] == '"1"':

        # Get view count
        if tokens[-1][:4] == "View":
            ViewCount = tokens[-1][11:-1]
        else:
            ViewCount = tokens[-2][11:-1]

        # Id for this question
        Id = tokens[0][4:-1]

        #Output: (ViewCount   Id)
        print(ViewCount + "\t" + Id)
