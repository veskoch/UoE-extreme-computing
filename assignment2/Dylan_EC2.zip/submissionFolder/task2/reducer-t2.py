#!/usr/bin/python
import sys
i = 0

for line in sys.stdin:

    # Input comes sorted (descending on counts) from the mappers/combiners
    # so we only want the first 10 lines
    if i < 10:
        ViewCount, Id = line.strip().split()
        print(ViewCount + " " + Id)
        i +=1
