#!/usr/bin/env python
import sys
import os

# Get the filename
fileName = os.environ["mapreduce_map_input_file"].split("/")[-1]


for line in sys.stdin:

    tokens = line.strip().split() # Split each line into tokens

    #Output (token  fileName) for each token
    for token in tokens:
         # Mapper and Combiner must have same output format
        print(token + "\t" + "\'" +fileName + "\':\'1\'")
