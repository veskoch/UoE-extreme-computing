python deduplicate.py /afs/inf.ed.ac.uk/group/teaching/exc/ex2/part3/webLarge.txt 1897987 0.01 > result.txt
