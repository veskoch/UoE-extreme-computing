#!/usr/bin/env python
from hashlib import md5
import numpy as np
import math
import sys

class BloomFilter:

    def __init__(self, num_keys, fpr):

        """
        -Constructor for my bloom filter implementation.
        -Calculates the size (m) of the bloom filter from the
         number of unique keys and desired false positive rate
        -Calculates the number of filters (hash fns) required
        -Initializes the array to be all zeros

        Args:
            self: A new object
            num_keys: The number of unique keys
            fpr: The desired false positive rate

        Returns:
            N/A
        """

        # The size of the array we will use as our bloom filter
        self.size = math.ceil((num_keys * math.log(fpr)) / math.log(1.0 / (math.pow(2.0, math.log(2.0)))))
        # The number of filters (hash functions) to use when inserting/querying our BF
        self.num_filters = int(round(math.log(2.0 * self.size / num_keys)))
        # Create the array and initilize it to all zeros
        self.array = np.zeros(self.size)

    def duplicate(self, key):

        """
        -The given key is inserted and queried in one pass
        -Calculates k positions in the BF using the k hash functions
        -If the value at any of the k positions is 0 we switch the
         duplicate flag to false, but before returning this value
         we first finish setting all of the other k positions to be 1.

        Args:
            self: self
            (int) num_keys: The number of unique keys
            (float) fpr: The desired false positive rate

        Returns:
            (bool) false: Key has definitely not been seen so far
                   true: Key may be in the filter
        """


        duplicate = True
        for seed in range(self.num_filters):
            index = int(md5(str(seed+1)+"_"+key).hexdigest(), 16) % self.size
            if self.array[index] == 0:
                duplicate = False
                self.array[index] = 1
        return duplicate

    def insert(self, key):

        """
        -Inserts a given key into the BF
        -Calculates k positions in the BF using the k hash
         functions and sets the bit at each position = 1

        Args:
            self: self
            (str) key: The key to be inserted into the BF

        Returns:
            N/A
        """

        for seed in range(self.num_filters):
            index = int(md5(str(seed+1)+"_"+ key).hexdigest(), 16) % self.size
            self.array[index] = 1

    def query(self, key):

        """
        -Queries the BF for a given key
        -Calculates k positions in the BF using the k hash functions
        -If the value at any of the k positions is 0, this key has not
         been inserted into the BF, return false
        -If the value at all k positions is 1, we believe this key
         could have been inserted to the BF, return true

        Args:
            self: self
            (str) key: The key we wish to query in the BF

        Returns:
            (bool) false: Key is definitely not in BF
                   true: Key could be in BF
        """
        for seed in range(self.num_filters):
            index = int(md5(str(seed+1)+"_"+ key).hexdigest(), 16)  % self.size
            if self.array[index] == 0:
                return False
        return True


fileName = sys.argv[1] # The file we wish to deduplicate
num_lines = int(sys.argv[2]) # The number of lines in the file
fpr = float(sys.argv[3]) # The false positive rate
bf = BloomFilter(num_lines,fpr) # Create an instance of our bloom filter

with open(fileName) as f: # Open the file

    for line in f:
        line = line.strip()
        # If bf.duplicate() returns false we know this line has definitely not been seen before
        if not bf.duplicate(line):
            print(line)
