#!/usr/bin/python
import sys
import re

for line in sys.stdin:
    # Split on the 4th whitespace, then drop first token
    postId, postType, checkAA, remainder = line.strip().split(" ", 4)[1:]

    # Question
    if postType[-3:] == '"1"':
        # Has an accepted answer
        if checkAA[0] == "A":
            questionID = postId[4:-1]
            # Get the accepted answer id
            acceptedAnswerID = checkAA.split("=")[1][1:-1]
            # Print the answer id and the question id
            print(acceptedAnswerID + "\t" + questionID)

    # Answer
    else:
        # Get the owner Id of each answer
        ownerUserID = re.findall('OwnerUserId="[0-9]+"', remainder)[0][13:-1]
        answerID = postId[4:-1]
        # Print the answer id and ownerUserId
        print(answerID + "\t" + "o" + ownerUserID)
