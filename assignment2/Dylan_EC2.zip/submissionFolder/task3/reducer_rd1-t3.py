#!/usr/bin/python
import sys

prevAnswerID = None
prevSecondID = None

for line in sys.stdin:

    # Second ID will be either the userOwnerID or questionID
    nextAnswerID, nextSecondID = line.strip().split("\t")

    # We have a match
    if nextAnswerID == prevAnswerID:
        # Output is: (ownerUserId    questionID)
        if prevSecondID[0] == "o":
            print(prevSecondID[1:] + "\t" + nextSecondID)
        else:
            print(nextSecondID[1:] + "\t" + prevSecondID)

    # set variables for next iteraion
    prevAnswerID = nextAnswerID
    prevSecondID = nextSecondID
