#!/usr/bin/python
import sys

prevUserId = None
questionIds = [] # Assuming there's a reasonable bound on the number of questionIDs here as we have to output it on one line
winnerId = None # Id of the current winning user
winnerQuestions = [] # Assuming there's a reasonable bound on the number of questionIDs here as we have to output it on one line

for line in sys.stdin:

    nextUserId, questionId = line.strip().split("\t")

    # Same user, so append to this users list of question ids
    if nextUserId == prevUserId:
        questionIds.append(questionId)

    else:
        # i.e. not first line
        if prevUserId:
            # check if prev user has more questions than current winner
            if len(winnerQuestions) < len(questionIds):
                winnerQuestions = questionIds
                winnerid = prevUserId
            # reset question ids
            questionIds = []

        # prepare for next iteration
        prevUserId = nextUserId
        winnerId = nextUserId
        questionIds.append(questionId)

# Don't forget about the last line
if prevUserId:
    if len(winnerQuestions) < len(questionIds):
        winnerQuestions = questionIds
        winnerId = prevUserId

# Finally print the winner (if valid input)
if winnerId:
    print(winnerId + " -> " + ", ".join(winnerQuestions))
