time hadoop jar /opt/hadoop/hadoop-2.7.3/share/hadoop/tools/lib/hadoop-streaming-2.7.3.jar \
-D mapred.reduce.tasks=1 \
-D mapred.output.key.comparator.class=org.apache.hadoop.mapred.lib.KeyFieldBasedComparator \
-D mapred.text.key.comparator.options=-k1,1n \
-input /data/assignments/ex2/part2/stackLarge.txt \
-output /user/s1774383/assignment2/temp/task3/ \
-mapper mapper_rd1-t3.py \
-file /afs/inf.ed.ac.uk/user/s17/s1774383/EC/A2/submissionFolder/task3/mapper_rd1-t3.py \
-reducer reducer_rd1-t3.py \
-file /afs/inf.ed.ac.uk/user/s17/s1774383/EC/A2/submissionFolder/task3/reducer_rd1-t3.py

time hadoop jar /opt/hadoop/hadoop-2.7.3/share/hadoop/tools/lib/hadoop-streaming-2.7.3.jar \
-D mapred.reduce.tasks=1 \
-input /user/s1774383/assignment2/temp/task3/ \
-output /user/s1774383/assignment2/task3/ \
-mapper cat \
-reducer reducer_rd2-t3.py \
-file /afs/inf.ed.ac.uk/user/s17/s1774383/EC/A2/submissionFolder/task3/reducer_rd2-t3.py
